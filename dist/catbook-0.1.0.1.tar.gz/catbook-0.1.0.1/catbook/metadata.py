import abc


class Metadata(metaclass=abc.ABCMeta):
    pass
